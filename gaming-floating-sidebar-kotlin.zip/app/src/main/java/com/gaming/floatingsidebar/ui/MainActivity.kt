package com.gaming.floatingsidebar.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gaming.floatingsidebar.R
import com.gaming.floatingsidebar.data.AppPreferences
import com.gaming.floatingsidebar.service.FloatingSidebarService

/**
 * الشاشة الرئيسية للتطبيق:
 * - التحقق من إذن SYSTEM_ALERT_WINDOW (الظهور فوق التطبيقات الأخرى).
 * - تشغيل وإيقاف خدمة Foreground Service.
 * - الانتقال لشاشة تخصيص التطبيقات المفضلة.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var preferences: AppPreferences
    private lateinit var btnToggleService: Button
    private lateinit var btnSelectApps: Button
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preferences = AppPreferences(this)

        btnToggleService = findViewById(R.id.btnToggleService)
        btnSelectApps = findViewById(R.id.btnSelectApps)
        tvStatus = findViewById(R.id.tvServiceStatus)

        updateUiState()

        btnToggleService.setOnClickListener {
            if (!checkOverlayPermission()) {
                requestOverlayPermission()
            } else {
                toggleFloatingService()
            }
        }

        btnSelectApps.setOnClickListener {
            val intent = Intent(this, AppSelectionActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        updateUiState()
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Toast.makeText(this, "يرجى تفعيل إذن الظهور فوق التطبيقات لتشغيل الشريط الجانبي", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
        }
    }

    private fun toggleFloatingService() {
        val isRunning = preferences.isServiceRunning()
        val intent = Intent(this, FloatingSidebarService::class.java)

        if (isRunning) {
            stopService(intent)
            preferences.setServiceRunning(false)
            Toast.makeText(this, "تم إيقاف الشريط الجانبي", Toast.LENGTH_SHORT).show()
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            preferences.setServiceRunning(true)
            Toast.makeText(this, "تم تفعيل الشريط الجانبي الطافي فوق الألعاب!", Toast.LENGTH_SHORT).show()
        }

        updateUiState()
    }

    private fun updateUiState() {
        val hasPermission = checkOverlayPermission()
        val isRunning = preferences.isServiceRunning()

        if (!hasPermission) {
            tvStatus.text = "الحالة: يتطلب إذن الظهور فوق التطبيقات"
            tvStatus.setTextColor(getColor(android.R.color.holo_orange_light))
            btnToggleService.text = "منح الإذن وتفعيل الخدمة"
        } else if (isRunning) {
            tvStatus.text = "الحالة: الشريط الجانبي نشط ويعمل فوق الألعاب"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_light))
            btnToggleService.text = "إيقاف الشريط الجانبي"
        } else {
            tvStatus.text = "الحالة: متوقف"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_light))
            btnToggleService.text = "بدء تشغيل الشريط الجانبي"
        }
    }

    companion object {
        private const val OVERLAY_PERMISSION_REQ_CODE = 2001
    }
}