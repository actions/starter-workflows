package com.gaming.floatingsidebar.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.gaming.floatingsidebar.R
import com.gaming.floatingsidebar.model.AppItem

class AppSelectionAdapter(
    private val apps: List<AppItem>
) : RecyclerView.Adapter<AppSelectionAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivIcon: ImageView = view.findViewById(R.id.ivSelectAppIcon)
        val tvName: TextView = view.findViewById(R.id.tvSelectAppName)
        val tvPkg: TextView = view.findViewById(R.id.tvSelectAppPkg)
        val cbSelect: CheckBox = view.findViewById(R.id.cbSelectApp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app_selection, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.tvName.text = app.appName
        holder.tvPkg.text = app.packageName
        holder.cbSelect.isChecked = app.isSelected

        if (app.icon != null) {
            holder.ivIcon.setImageDrawable(app.icon)
        } else {
            holder.ivIcon.setImageResource(android.R.drawable.sym_def_app_icon)
        }

        holder.itemView.setOnClickListener {
            app.isSelected = !app.isSelected
            holder.cbSelect.isChecked = app.isSelected
        }

        holder.cbSelect.setOnCheckedChangeListener { _, isChecked ->
            app.isSelected = isChecked
        }
    }

    override fun getItemCount() = apps.size
}