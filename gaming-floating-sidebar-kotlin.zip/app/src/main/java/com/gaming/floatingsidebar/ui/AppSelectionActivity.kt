package com.gaming.floatingsidebar.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gaming.floatingsidebar.R
import com.gaming.floatingsidebar.data.AppPreferences
import com.gaming.floatingsidebar.model.AppItem

/**
 * شاشة استعراض كل التطبيقات المثبتة في الهاتف والسماح للمستخدم
 * بتحديد التطبيقات التي يريد ظهورها في الشريط الجانبي، وحفظها في SharedPreferences.
 */
class AppSelectionActivity : AppCompatActivity() {

    private lateinit var preferences: AppPreferences
    private lateinit var rvAllApps: RecyclerView
    private lateinit var btnSave: Button
    private lateinit var adapter: AppSelectionAdapter
    private val appList = mutableListOf<AppItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_selection)

        preferences = AppPreferences(this)
        rvAllApps = findViewById(R.id.rvAllApps)
        btnSave = findViewById(R.id.btnSaveApps)

        rvAllApps.layoutManager = LinearLayoutManager(this)

        loadInstalledApps()

        btnSave.setOnClickListener {
            saveFavorites()
        }
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val savedFavorites = preferences.getFavoritePackages()

        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        appList.clear()

        for (info in resolveInfos) {
            val pkg = info.activityInfo.packageName
            // تجاهل تطبيقنا الحالي
            if (pkg == packageName) continue

            val appName = info.loadLabel(pm).toString()
            val icon = info.loadIcon(pm)
            val isSelected = savedFavorites.contains(pkg)

            appList.add(AppItem(pkg, appName, icon, isSelected))
        }

        appList.sortBy { it.appName }

        adapter = AppSelectionAdapter(appList)
        rvAllApps.adapter = adapter
    }

    private fun saveFavorites() {
        val selectedPackages = appList.filter { it.isSelected }.map { it.packageName }.toSet()
        preferences.saveFavoritePackages(selectedPackages)

        Toast.makeText(this, "تم حفظ التطبيقات المفضلة للشريط الجانبي!", Toast.LENGTH_SHORT).show()
        finish()
    }
}