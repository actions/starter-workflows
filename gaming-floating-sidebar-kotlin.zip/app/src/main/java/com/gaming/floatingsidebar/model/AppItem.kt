package com.gaming.floatingsidebar.model

import android.graphics.drawable.Drawable

/**
 * نموذج بيانات يمثل تطبيقاً مثبتاً في الهاتف
 */
data class AppItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    var isSelected: Boolean = false
)