package com.gaming.floatingsidebar.data

import android.content.Context
import android.content.SharedPreferences

/**
 * إدارة حفظ واسترجاع التطبيقات المفضلة وحالة الشريط الجانبي
 * عبر SharedPreferences.
 */
class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("gaming_sidebar_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_FAVORITE_PACKAGES = "key_favorite_packages"
        private const val KEY_SERVICE_RUNNING = "key_service_running"
        private const val KEY_WINDOW_ALPHA = "key_window_alpha"

        // تطبيقات مقترحة افتراضياً
        val DEFAULT_PACKAGES = setOf(
            "com.whatsapp",
            "com.discord",
            "org.telegram.messenger",
            "com.google.android.youtube"
        )
    }

    fun getFavoritePackages(): Set<String> {
        return prefs.getStringSet(KEY_FAVORITE_PACKAGES, DEFAULT_PACKAGES) ?: DEFAULT_PACKAGES
    }

    fun saveFavoritePackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_FAVORITE_PACKAGES, packages).apply()
    }

    fun isServiceRunning(): Boolean {
        return prefs.getBoolean(KEY_SERVICE_RUNNING, false)
    }

    fun setServiceRunning(isRunning: Boolean) {
        prefs.edit().putBoolean(KEY_SERVICE_RUNNING, isRunning).apply()
    }

    fun getWindowAlpha(): Float {
        return prefs.getFloat(KEY_WINDOW_ALPHA, 0.90f)
    }

    fun saveWindowAlpha(alpha: Float) {
        prefs.edit().putFloat(KEY_WINDOW_ALPHA, alpha).apply()
    }
}