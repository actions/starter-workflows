package com.gaming.floatingsidebar.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.gaming.floatingsidebar.R
import com.gaming.floatingsidebar.data.AppPreferences
import com.gaming.floatingsidebar.model.AppItem
import com.gaming.floatingsidebar.ui.MainActivity
import com.gaming.floatingsidebar.ui.SidebarAppsAdapter
import kotlin.math.abs

/**
 * خدمة Foreground Service المسؤولة عن تشغيل الشريط الجانبي الطافي فوق الألعاب والتطبيقات.
 * تدير كلاً من:
 * 1. نتوء الشريط الجانبي (Sidebar Handle) القابل للتحريك والالتصاق بالحافة.
 * 2. القائمة الجانبية المنبثقة للتطبيقات المفضلة (Drawer).
 * 3. النافذة العائمة (Floating Window) مع شريط سحب وتحكم بالشفافية (Alpha) والحجم.
 */
class FloatingSidebarService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var preferences: AppPreferences

    // عناصر العرض الطافية (Views)
    private var handleView: View? = null
    private var drawerView: View? = null
    private var floatingWindowView: View? = null

    // معايير التخطيط لـ WindowManager
    private lateinit var handleParams: WindowManager.LayoutParams
    private lateinit var drawerParams: WindowManager.LayoutParams
    private lateinit var windowParams: WindowManager.LayoutParams

    private var isDrawerOpen = false
    private val screenSize = Point()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        preferences = AppPreferences(this)

        updateScreenSize()
        startForegroundWithNotification()

        initHandleView()
    }

    private fun updateScreenSize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val insets = windowMetrics.windowInsets
            val bounds = windowMetrics.bounds
            screenSize.x = bounds.width()
            screenSize.y = bounds.height()
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getSize(screenSize)
        }
    }

    /**
     * تشغيل الخدمة كـ Foreground Service مع إشعار دائم لتجنب إيقافها من قِبل نظام أندرويد
     */
    private fun startForegroundWithNotification() {
        val channelId = "gaming_sidebar_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Gaming Floating Sidebar",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "الخدمة النشطة للشريط الجانبي الطافي للألعاب"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("الشريط الجانبي للألعاب مفعّل")
            .setContentText("المقبض الطافي جاهز فوق الألعاب والتطبيقات")
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    // =========================================================================
    // 1. إعداد وبرمجة النتوء الصغير (Sidebar Handle)
    // =========================================================================
    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun initHandleView() {
        val inflater = LayoutInflater.from(this)
        handleView = inflater.inflate(R.layout.view_sidebar_handle, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        handleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0 // الافتراضي: الالتصاق بالحافة اليسرى
            y = screenSize.y / 3
        }

        // مستشعر لمس المقبض (سحب، تحريك، نقر، والتصاق بالحافة)
        handleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = handleParams.x
                        initialY = handleParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY

                        if (abs(dx) > 10 || abs(dy) > 10) {
                            isDragging = true
                        }

                        if (isDragging) {
                            handleParams.x = (initialX + dx).toInt()
                            handleParams.y = (initialY + dy).toInt()
                            windowManager.updateViewLayout(handleView, handleParams)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDragging) {
                            // نقرة سريعة -> فتح/إغلاق القائمة الجانبية
                            toggleDrawer()
                        } else {
                            // إفلات السحب -> الالتصاق بأقرب حافة (يمين أو يسار)
                            snapHandleToNearestEdge()
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(handleView, handleParams)
    }

    /**
     * الالتصاق التلقائي بأقرب حافة للشاشة (يسار أو يمين)
     */
    private fun snapHandleToNearestEdge() {
        val middleX = screenSize.x / 2
        handleParams.x = if (handleParams.x < middleX) {
            0 // الحافة اليسرى
        } else {
            screenSize.x - (handleView?.width ?: 120) // الحافة اليمنى
        }
        windowManager.updateViewLayout(handleView, handleParams)
    }

    // =========================================================================
    // 2. إعداد القائمة الجانبية للتطبيقات (Sidebar Drawer)
    // =========================================================================
    @SuppressLint("InflateParams")
    private fun toggleDrawer() {
        if (isDrawerOpen) {
            closeDrawer()
        } else {
            openDrawer()
        }
    }

    private fun openDrawer() {
        if (drawerView != null) return

        val inflater = LayoutInflater.from(this)
        drawerView = inflater.inflate(R.layout.view_sidebar_drawer, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // تحديد ما إذا كان المقبض في اليسار أو اليمين
        val isLeftEdge = handleParams.x < (screenSize.x / 2)

        drawerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or (if (isLeftEdge) Gravity.START else Gravity.END)
            x = (handleView?.width ?: 100) + 16
            y = handleParams.y - 100
        }

        // إغلاق عند النقر خارج القائمة
        drawerView?.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_OUTSIDE) {
                closeDrawer()
                true
            } else false
        }

        // إعداد قائمة التطبيقات المفضلة
        val rvApps = drawerView?.findViewById<RecyclerView>(R.id.rvSidebarApps)
        rvApps?.layoutManager = LinearLayoutManager(this)

        val favoritePackages = preferences.getFavoritePackages()
        val appsList = loadAppItems(favoritePackages)

        val adapter = SidebarAppsAdapter(appsList) { selectedApp ->
            closeDrawer()
            openFloatingWindow(selectedApp)
        }
        rvApps?.adapter = adapter

        // زر فتح إعدادات تخصيص التطبيقات
        drawerView?.findViewById<View>(R.id.btnCustomizeApps)?.setOnClickListener {
            closeDrawer()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }

        windowManager.addView(drawerView, drawerParams)
        isDrawerOpen = true
    }

    private fun closeDrawer() {
        if (drawerView != null && isDrawerOpen) {
            windowManager.removeView(drawerView)
            drawerView = null
            isDrawerOpen = false
        }
    }

    // =========================================================================
    // 3. النافذة العائمة (Floating Window) مع شريط السحب، والشفافية، والحجم
    // =========================================================================
    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun openFloatingWindow(app: AppItem) {
        // إغلاق أي نافذة عائمة سابقة إن وجدت
        closeFloatingWindow()

        val inflater = LayoutInflater.from(this)
        floatingWindowView = inflater.inflate(R.layout.view_floating_window, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // أبعاد النافذة الافتراضية
        val defaultWidth = (screenSize.x * 0.75).toInt().coerceAtMost(900)
        val defaultHeight = (screenSize.y * 0.55).toInt().coerceAtMost(1200)

        windowParams = WindowManager.LayoutParams(
            defaultWidth,
            defaultHeight,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }

        // تعيين العنوان والأيقونة
        val tvTitle = floatingWindowView?.findViewById<TextView>(R.id.tvFloatingTitle)
        val ivIcon = floatingWindowView?.findViewById<ImageView>(R.id.ivFloatingAppIcon)
        tvTitle?.text = app.appName
        if (app.icon != null) {
            ivIcon?.setImageDrawable(app.icon)
        }

        // 1. شريط علوي للتحريك (Drag & Move)
        val headerDragBar = floatingWindowView?.findViewById<View>(R.id.headerDragBar)
        headerDragBar?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = windowParams.x
                        initialY = windowParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        windowParams.x = (initialX + (event.rawX - initialTouchX)).toInt()
                        windowParams.y = (initialY + (event.rawY - initialTouchY)).toInt()
                        windowManager.updateViewLayout(floatingWindowView, windowParams)
                        return true
                    }
                }
                return false
            }
        })

        // 2. زر الإغلاق
        val btnClose = floatingWindowView?.findViewById<ImageButton>(R.id.btnFloatingClose)
        btnClose?.setOnClickListener {
            closeFloatingWindow()
        }

        // 3. أزرار التحكم بحجم النافذة (تكبير وتصغير)
        var isMaximized = false
        val btnResize = floatingWindowView?.findViewById<ImageButton>(R.id.btnFloatingResize)
        btnResize?.setOnClickListener {
            if (!isMaximized) {
                // تكبير لشبه ملء الشاشة
                windowParams.width = (screenSize.x * 0.92).toInt()
                windowParams.height = (screenSize.y * 0.85).toInt()
                isMaximized = true
                btnResize.setImageResource(android.R.drawable.arrow_down_float)
            } else {
                // استعادة الحجم الافتراضي
                windowParams.width = defaultWidth
                windowParams.height = defaultHeight
                isMaximized = false
                btnResize.setImageResource(android.R.drawable.arrow_up_float)
            }
            windowManager.updateViewLayout(floatingWindowView, windowParams)
        }

        // 4. شريط منزلق (Slider / SeekBar) لتعديل درجة شفافية النافذة (Alpha)
        val seekBarAlpha = floatingWindowView?.findViewById<SeekBar>(R.id.seekBarAlpha)
        val tvAlphaPercent = floatingWindowView?.findViewById<TextView>(R.id.tvAlphaPercent)

        seekBarAlpha?.max = 100
        seekBarAlpha?.progress = 90 // الشفافية الافتراضية 90%
        tvAlphaPercent?.text = "90%"

        seekBarAlpha?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // منع الشفافية الكاملة، الحد الأدنى 20%
                val safeProgress = progress.coerceAtLeast(20)
                val alphaFloat = safeProgress / 100f
                floatingWindowView?.alpha = alphaFloat
                tvAlphaPercent?.text = "$safeProgress%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // مساحة المحتوى الخاص بالتطبيق (حاوية تشغيل أو إطلاق التطبيق)
        val containerContent = floatingWindowView?.findViewById<FrameLayout>(R.id.containerAppContent)
        setupFloatingAppContent(containerContent, app)

        windowManager.addView(floatingWindowView, windowParams)
    }

    private fun setupFloatingAppContent(container: FrameLayout?, app: AppItem) {
        val context = this
        val view = LayoutInflater.from(context).inflate(R.layout.view_floating_inner_content, container, false)
        val tvDesc = view.findViewById<TextView>(R.id.tvInnerAppDesc)
        val btnLaunchFull = view.findViewById<View>(R.id.btnLaunchDirect)

        tvDesc.text = "نافذة طافية مخصصة لـ ${app.appName}. يمكنك استخدامها أثناء اللعب دون الخروج."

        btnLaunchFull.setOnClickListener {
            // إطلاق التطبيق في نافذة عائمة حرة (Freeform Window إذا كان الجهاز يدعمها)
            val launchIntent = packageManager.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                // دعم أندرويد لخاصية النوافذ العائمة عند تفعيل Freeform Multi-Window
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                startActivity(launchIntent)
            }
        }

        container?.removeAllViews()
        container?.addView(view)
    }

    private fun closeFloatingWindow() {
        if (floatingWindowView != null) {
            windowManager.removeView(floatingWindowView)
            floatingWindowView = null
        }
    }

    // =========================================================================
    // مساعدة: جلب أسماء التطبيقات والأيقونات من PackageManager
    // =========================================================================
    private fun loadAppItems(packageNames: Set<String>): List<AppItem> {
        val pm = packageManager
        val list = mutableListOf<AppItem>()

        for (pkg in packageNames) {
            try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                val name = pm.getApplicationLabel(appInfo).toString()
                val icon = pm.getApplicationIcon(appInfo)
                list.add(AppItem(pkg, name, icon, true))
            } catch (e: Exception) {
                // إذا لم يتم العثور على الحزمة
                list.add(AppItem(pkg, pkg.substringAfterLast('.'), null, true))
            }
        }

        if (list.isEmpty()) {
            // قائمة افتراضية في حال لم يختر المستخدم بعد
            list.add(AppItem("com.whatsapp", "WhatsApp", null, true))
            list.add(AppItem("com.discord", "Discord", null, true))
        }

        return list
    }

    override fun onDestroy() {
        super.onDestroy()
        if (handleView != null) windowManager.removeView(handleView)
        if (drawerView != null) windowManager.removeView(drawerView)
        if (floatingWindowView != null) windowManager.removeView(floatingWindowView)
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}