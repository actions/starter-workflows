# android-repository-history
History of Android repository XML

## repository2-$N.xml and addons_list-3.xml
Used by `sdkmanager` command.

## repository-$N.xml and addons_list-2.xml
Used by `android` command, which is deprecated and unavailable in the latest Android SDK Tools (since r25.3.0)
